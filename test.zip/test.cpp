#include <iostream> // 引入輸入輸出流庫

int main() {
    std::cout << "Hello NSSPC 2024 Preliminary!" << std::endl; // 使用 cout 輸出文字
    return 0; // 返回 0 表示程式成功結束
}
